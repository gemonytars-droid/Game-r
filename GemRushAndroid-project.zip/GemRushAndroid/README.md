# Gem Rush — Android APK project

The HTML game is packaged locally in an Android WebView; no network permission or third-party runtime is required.

## Build a free APK using GitHub Actions (phone-friendly)
1. Create a new GitHub repository and upload the **contents** of this folder (not the enclosing folder itself).
2. Open the repository's **Actions** tab and allow workflows if GitHub asks.
3. The workflow runs after the push to `main`. You can also open **Build Gem Rush APK** and choose **Run workflow**.
4. Open the completed workflow run, scroll to **Artifacts**, and download `GemRush-debug-apk`.
5. Extract the ZIP and install `app-debug.apk` on Android. If prompted, allow your browser/file manager to install unknown apps.

This is a debug APK for personal testing, not a Play Store release. For a public release, create a signed release build.
